#ifndef PAINTAPP_H
#define PAINTAPP_H

#include <QMainWindow>
#include<QPaintEvent>
#include<QPainter>
#include<QImage>
#include<QMouseEvent>
#include<QColorDialog>
#include<QDesktopWidget>
#include<QInputDialog>
#include<QPen>
#include<QColor>
#include<QByteArray>
#include<QMessageBox>
#include<QFileDialog>

QT_BEGIN_NAMESPACE
namespace Ui { class PaintAPP; }
QT_END_NAMESPACE
class QPainter;
class QImage;


class PaintAPP : public QMainWindow
{
    Q_OBJECT

public:
    PaintAPP(QWidget *parent = nullptr);
    ~PaintAPP();
protected :
//evenemet de peinture
void paintEvent(QPaintEvent *e) override;
//l'evenement d'appui sur la souris
void mousePressEvent(QMouseEvent *e) override;
//l'evenement de deplacement de la souris primordial
void mouseMoveEvent(QMouseEvent *e) override ;
//evenements de relachement de la souris primordial
void mouseReleaseEvent(QMouseEvent *e) override ;

private slots:
void on_actionPen_Size_triggered();

void on_actionColor_triggered();

void on_actionAbout_Qt_triggered();

void on_actionSave_triggered();

void on_actionGo_triggered();

void on_actionClear_All_triggered();

private:
    Ui::PaintAPP *ui;
    QPainter *Painter;
    QImage *Image;
    //declarons les deux points de depart et de final
    QPoint Begin;
    QPoint End;
    bool ispaint;
    int size;
    QColor color;

};
#endif // PAINTAPP_H
