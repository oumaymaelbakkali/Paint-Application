#include "paintapp.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    a.setStyle("fusion");
    QPixmap Icon(":/Paint.png");
    PaintAPP w;
    w.setWindowIcon(Icon);


    w.show();

    return a.exec();
}
