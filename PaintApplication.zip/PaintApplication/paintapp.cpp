#include "paintapp.h"
#include "ui_paintapp.h"
#include<QDataStream>
#define DEFAULT_SIZE 5






PaintAPP::PaintAPP(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::PaintAPP)
{
    ui->setupUi(this);
    Image=new QImage(QApplication::desktop()->size(),QImage::Format_ARGB32_Premultiplied);
    Image->fill(Qt::white);
    Painter= new QPainter(Image);
    ispaint=false;
    color=QColor(Qt::black);
    size = DEFAULT_SIZE;

}

PaintAPP::~PaintAPP()
{
    delete ui;
}
void PaintAPP::paintEvent(QPaintEvent *e){
    //poser image sur le widget central
    QPainter painter(this);
    //paint une  image
    painter.drawImage(0, 0,*Image);
    e->accept();
}
void PaintAPP::mouseMoveEvent(QMouseEvent *e){
    if(!ispaint){
       e->accept();
       return;
    }
    QPen pen(color);
    pen.setCapStyle(Qt::RoundCap);
    pen.setWidth(size);
    Painter->setPen(pen);
    End=e->pos();
    //paint sur la variable image qui on a paint et on a la posé sur le central widget
    Painter->drawLine(Begin,End);
    Begin= End;
     update();
    e->accept();

}
void PaintAPP::mousePressEvent(QMouseEvent *e){

    //l'orseque nous appuyons sur la souris
    //on active la peinture
    ispaint=true;
    //le premiere point c'est la position de cursus
    Begin=e->pos();
    e->accept();

}
void PaintAPP::mouseReleaseEvent(QMouseEvent *e){
   ispaint=false;
   e->accept();
}


void PaintAPP::on_actionPen_Size_triggered()
{
   size=QInputDialog::getInt(this, "choose your pen size","Pen size :",5 ,1);
}

void PaintAPP::on_actionColor_triggered()
{
    color =QColorDialog::getColor(Qt::black,this,"color de  ");

}

void PaintAPP::on_actionAbout_Qt_triggered()
{

QMessageBox ::aboutQt(this,"about QT");
}

void PaintAPP::on_actionSave_triggered()
{
    QString fileName = QFileDialog::getSaveFileName(this, tr("Save Image File"),
                                                    QString(),tr("Images (*.png)"));
    if (!fileName.isEmpty())
    {
      Image->save(fileName);
    }
  }







void PaintAPP::on_actionGo_triggered()
{
    close();
}

void PaintAPP::on_actionClear_All_triggered()
{
     Image->fill(Qt::white);
     update();
}
